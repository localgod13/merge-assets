
// src/game/objects/ui/index.ts

export { PauseButton } from './PauseButton'
